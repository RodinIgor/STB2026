using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;

namespace STB2026
{
    /// <summary>
    /// Команда "Привет мир" — первый тестовый плагин STB2026.
    /// Выводит диалоговое окно с приветственным сообщением.
    /// </summary>
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class HelloWorldCommand : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            ElementSet elements)
        {
            try
            {
                // Получаем доступ к текущему документу и приложению
                UIApplication uiApp = commandData.Application;
                UIDocument uiDoc = uiApp.ActiveUIDocument;
                Document doc = uiDoc.Document;

                // Формируем информационное сообщение
                string projectName = doc.Title;
                string userName = uiApp.Application.Username;

                string infoMessage =
                    "Привет мир!\n\n" +
                    "═══════════════════════════════════\n" +
                    "Плагин STB2026 успешно загружен.\n" +
                    "═══════════════════════════════════\n\n" +
                    $"Проект: {projectName}\n" +
                    $"Пользователь: {userName}\n" +
                    $"Версия Revit: {uiApp.Application.VersionNumber}\n" +
                    $"Дата и время: {DateTime.Now:dd.MM.yyyy HH:mm:ss}\n\n" +
                    "Разработка в соответствии с:\n" +
                    "• ПП РФ №87 (Состав разделов проектной документации)\n" +
                    "• СП 60.13330.2020 (Отопление, вентиляция, кондиционирование)\n" +
                    "• Действующие нормы и правила РФ";

                TaskDialog dialog = new TaskDialog("STB2026 — Привет мир");
                dialog.MainInstruction = "Привет мир!";
                dialog.MainContent = infoMessage;
                dialog.CommonButtons = TaskDialogCommonButtons.Ok;
                dialog.DefaultButton = TaskDialogResult.Ok;
                dialog.TitleAutoPrefix = false;
                dialog.MainIcon = TaskDialogIcon.TaskDialogIconInformation;

                dialog.Show();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = $"Ошибка выполнения команды: {ex.Message}";
                TaskDialog.Show("STB2026 — Ошибка", message);
                return Result.Failed;
            }
        }
    }
}
