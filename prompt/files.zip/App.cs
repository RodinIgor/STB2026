using Autodesk.Revit.UI;
using System;
using System.IO;
using System.Reflection;
using System.Windows.Media.Imaging;

namespace STB2026
{
    /// <summary>
    /// Главный класс приложения STB2026.
    /// Регистрирует вкладку, панель и кнопки на ленте Revit.
    /// Реализует IExternalApplication для автоматической загрузки при старте Revit.
    /// </summary>
    public class App : IExternalApplication
    {
        // Имя вкладки и панели на ленте Revit
        private const string TabName = "STB2026";
        private const string PanelName = "Основные";

        public Result OnStartup(UIControlledApplication application)
        {
            try
            {
                // 1. Создаём собственную вкладку на ленте
                application.CreateRibbonTab(TabName);

                // 2. Создаём панель внутри вкладки
                RibbonPanel panel = application.CreateRibbonPanel(TabName, PanelName);

                // 3. Получаем путь к текущей сборке (dll)
                string assemblyPath = Assembly.GetExecutingAssembly().Location;

                // 4. Создаём данные для кнопки "Привет мир"
                PushButtonData helloButtonData = new PushButtonData(
                    name: "cmdHelloWorld",
                    text: "Привет\nмир",
                    assemblyName: assemblyPath,
                    className: "STB2026.HelloWorldCommand"
                );

                // 5. Настраиваем подсказку
                helloButtonData.ToolTip = "Показать приветственное окно STB2026";
                helloButtonData.LongDescription =
                    "Тестовая команда плагина STB2026.\n" +
                    "Выводит диалоговое окно с информацией о проекте,\n" +
                    "пользователе и версии Revit.\n\n" +
                    "Разработка ведётся в соответствии с ПП РФ №87\n" +
                    "и действующими нормами РФ.";

                // 6. Добавляем кнопку на панель
                PushButton helloButton = panel.AddItem(helloButtonData) as PushButton;

                // 7. Пытаемся загрузить иконку (если есть)
                try
                {
                    string iconDir = Path.GetDirectoryName(assemblyPath);
                    string iconPath = Path.Combine(iconDir, "Resources", "hello_32.png");
                    if (File.Exists(iconPath))
                    {
                        BitmapImage icon = new BitmapImage(new Uri(iconPath));
                        helloButton.LargeImage = icon;
                    }
                }
                catch
                {
                    // Иконка не критична — кнопка будет работать и без неё
                }

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("STB2026 — Ошибка загрузки",
                    $"Не удалось инициализировать плагин:\n{ex.Message}");
                return Result.Failed;
            }
        }

        public Result OnShutdown(UIControlledApplication application)
        {
            // Здесь можно освободить ресурсы при закрытии Revit
            return Result.Succeeded;
        }
    }
}
